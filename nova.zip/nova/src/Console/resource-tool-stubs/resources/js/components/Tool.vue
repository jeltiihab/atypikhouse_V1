<template>
  <div>{{ title }}</div>
</template>

<script>
export default {
  props: ['resourceName', 'resourceId', 'panel'],

  mounted() {
    //
  },
}
</script>
