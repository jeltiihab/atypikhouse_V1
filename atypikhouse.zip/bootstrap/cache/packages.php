<?php return array (
  'armincms/json' => 
  array (
    'providers' => 
    array (
    ),
  ),
  'benjacho/belongs-to-many-field' => 
  array (
    'providers' => 
    array (
      0 => 'Benjacho\\BelongsToManyField\\FieldServiceProvider',
    ),
  ),
  'cloudstudio/resource-generator' => 
  array (
    'providers' => 
    array (
      0 => 'Cloudstudio\\ResourceGenerator\\ResourceGeneratorServiceProvider',
    ),
  ),
  'coroowicaksono/chart-js-integration' => 
  array (
    'providers' => 
    array (
      0 => 'Coroowicaksono\\ChartJsIntegration\\CardServiceProvider',
    ),
  ),
  'davidpiesse/nova-toggle' => 
  array (
    'providers' => 
    array (
      0 => 'Davidpiesse\\NovaToggle\\FieldServiceProvider',
    ),
  ),
  'digital-creative/chartjs-widget' => 
  array (
    'providers' => 
    array (
      0 => 'DigitalCreative\\ChartJsWidget\\WidgetServiceProvider',
    ),
  ),
  'digital-creative/collapsible-resource-manager' => 
  array (
    'providers' => 
    array (
      0 => 'DigitalCreative\\CollapsibleResourceManager\\CollapsibleResourceManagerServiceProvider',
    ),
  ),
  'digital-creative/nova-dashboard' => 
  array (
    'providers' => 
    array (
      0 => 'DigitalCreative\\NovaDashboard\\ToolServiceProvider',
    ),
  ),
  'digital-creative/nova-data-table' => 
  array (
    'providers' => 
    array (
      0 => 'DigitalCreative\\NovaDataTable\\CardServiceProvider',
    ),
  ),
  'digital-creative/nova-json-wrapper' => 
  array (
    'providers' => 
    array (
      0 => 'DigitalCreative\\JsonWrapper\\JsonWrapperServiceProvider',
    ),
  ),
  'digital-creative/nova-pill-filter' => 
  array (
    'providers' => 
    array (
      0 => 'DigitalCreative\\PillFilter\\PillFilterServiceProvider',
    ),
  ),
  'digital-creative/nova-range-input-filter' => 
  array (
    'providers' => 
    array (
      0 => 'DigitalCreative\\RangeInputFilter\\RangeInputFilterServiceProvider',
    ),
  ),
  'digital-creative/resource-navigation-tab' => 
  array (
    'providers' => 
    array (
      0 => 'DigitalCreative\\ResourceNavigationTab\\ResourceNavigationTabServiceProvider',
    ),
  ),
  'digital-creative/value-widget' => 
  array (
    'providers' => 
    array (
      0 => 'DigitalCreative\\ValueWidget\\ToolServiceProvider',
    ),
  ),
  'digitalazgroup/nova-plain-text-field' => 
  array (
    'providers' => 
    array (
      0 => 'Digitalazgroup\\PlainText\\FieldServiceProvider',
    ),
  ),
  'dillingham/nova-attach-many' => 
  array (
    'providers' => 
    array (
      0 => 'NovaAttachMany\\Providers\\FieldServiceProvider',
    ),
  ),
  'dillingham/nova-detail-link' => 
  array (
    'providers' => 
    array (
      0 => 'Dillingham\\NovaDetailLink\\FieldServiceProvider',
    ),
  ),
  'eminiarts/nova-relationship-selector' => 
  array (
    'providers' => 
    array (
      0 => 'Eminiarts\\RelationshipSelector\\FieldServiceProvider',
    ),
  ),
  'eminiarts/nova-tabs' => 
  array (
    'providers' => 
    array (
      0 => 'Eminiarts\\Tabs\\TabsServiceProvider',
    ),
  ),
  'enmaboya/country-select' => 
  array (
    'providers' => 
    array (
      0 => 'Enmaboya\\CountrySelect\\FieldServiceProvider',
    ),
  ),
  'enmaboya/place-input' => 
  array (
    'providers' => 
    array (
      0 => 'Enmaboya\\PlaceInput\\FieldServiceProvider',
    ),
  ),
  'epartment/nova-dependency-container' => 
  array (
    'providers' => 
    array (
      0 => 'Epartment\\NovaDependencyContainer\\FieldServiceProvider',
    ),
  ),
  'ericlagarda/nova-text-card' => 
  array (
    'providers' => 
    array (
      0 => 'Ericlagarda\\NovaTextCard\\CardServiceProvider',
    ),
  ),
  'facade/ignition' => 
  array (
    'providers' => 
    array (
      0 => 'Facade\\Ignition\\IgnitionServiceProvider',
    ),
    'aliases' => 
    array (
      'Flare' => 'Facade\\Ignition\\Facades\\Flare',
    ),
  ),
  'fruitcake/laravel-cors' => 
  array (
    'providers' => 
    array (
      0 => 'Fruitcake\\Cors\\CorsServiceProvider',
    ),
  ),
  'jason-guru/laravel-make-repository' => 
  array (
    'providers' => 
    array (
      0 => 'JasonGuru\\LaravelMakeRepository\\RepositoryServiceProvider',
    ),
  ),
  'kirschbaum-development/eloquent-power-joins' => 
  array (
    'providers' => 
    array (
      0 => 'Kirschbaum\\PowerJoins\\PowerJoinsServiceProvider',
    ),
  ),
  'kirschbaum-development/nova-comments' => 
  array (
    'providers' => 
    array (
      0 => 'KirschbaumDevelopment\\NovaComments\\NovaCommentsServiceProvider',
    ),
  ),
  'kirschbaum-development/nova-inline-relationship' => 
  array (
    'providers' => 
    array (
      0 => 'KirschbaumDevelopment\\NovaInlineRelationship\\NovaInlineRelationshipServiceProvider',
    ),
  ),
  'kirschbaum-development/nova-inline-select' => 
  array (
    'providers' => 
    array (
      0 => 'KirschbaumDevelopment\\Nova\\InlineSelectFieldServiceProvider',
    ),
  ),
  'klepak/nova-multiselect-filter' => 
  array (
    'providers' => 
    array (
      0 => 'Klepak\\NovaMultiselectFilter\\FilterServiceProvider',
    ),
  ),
  'laramaker/redirect-after-asset' => 
  array (
    'providers' => 
    array (
      0 => 'Laramaker\\RedirectAfterAsset\\AssetServiceProvider',
    ),
  ),
  'laraning/nova-time-field' => 
  array (
    'providers' => 
    array (
      0 => 'Laraning\\NovaTimeField\\FieldServiceProvider',
    ),
  ),
  'laravel/nova' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Nova\\NovaCoreServiceProvider',
    ),
    'aliases' => 
    array (
      'Nova' => 'Laravel\\Nova\\Nova',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/sanctum' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sanctum\\SanctumServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'laravel/ui' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Ui\\UiServiceProvider',
    ),
  ),
  'marispro/nova-inline-morph-to' => 
  array (
    'providers' => 
    array (
      0 => 'DigitalCreative\\InlineMorphTo\\FieldServiceProvider',
    ),
  ),
  'michielfb/laravel-nova-time-field' => 
  array (
    'providers' => 
    array (
      0 => 'Michielfb\\Time\\FieldServiceProvider',
    ),
  ),
  'naif/generate-password' => 
  array (
    'providers' => 
    array (
      0 => 'Naif\\GeneratePassword\\FieldServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nikaia/nova-rating-field' => 
  array (
    'providers' => 
    array (
      0 => 'Nikaia\\Rating\\RatingServiceProvider',
    ),
  ),
  'nova-bi/nova-dashboard-manager' => 
  array (
    'providers' => 
    array (
      0 => 'NovaBi\\NovaDashboardManager\\DashboardManagerServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'optimistdigital/nova-sortable' => 
  array (
    'providers' => 
    array (
      0 => 'OptimistDigital\\NovaSortable\\ToolServiceProvider',
    ),
  ),
  'optimistdigital/nova-translations-loader' => 
  array (
    'providers' => 
    array (
    ),
    'aliases' => 
    array (
    ),
  ),
  'pdmfc/nova-info-card' => 
  array (
    'providers' => 
    array (
      0 => 'Pdmfc\\NovaCards\\InfoCardServiceProvider',
    ),
  ),
  'rcknr/nova-multiselect-filter' => 
  array (
    'providers' => 
    array (
      0 => 'rcknr\\Nova\\Filters\\FilterServiceProvider',
    ),
  ),
  'runlinenl/nova-profile-tool' => 
  array (
    'providers' => 
    array (
      0 => 'Runline\\ProfileTool\\ToolServiceProvider',
    ),
  ),
  'santigarcor/laratrust' => 
  array (
    'providers' => 
    array (
      0 => 'Laratrust\\LaratrustServiceProvider',
    ),
    'aliases' => 
    array (
      'Laratrust' => 'Laratrust\\LaratrustFacade',
    ),
  ),
  'silvanite/nova-field-place' => 
  array (
    'providers' => 
    array (
      0 => 'Silvanite\\NovaFieldPlace\\FieldServiceProvider',
    ),
  ),
  'spatie/eloquent-sortable' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\EloquentSortable\\EloquentSortableServiceProvider',
    ),
  ),
  'spatie/laravel-schemaless-attributes' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\SchemalessAttributes\\SchemalessAttributesServiceProvider',
    ),
  ),
  'timothyasp/nova-badge-field' => 
  array (
    'providers' => 
    array (
      0 => 'Timothyasp\\Badge\\FieldServiceProvider',
    ),
  ),
  'timothyasp/nova-color-field' => 
  array (
    'providers' => 
    array (
      0 => 'Timothyasp\\Color\\FieldServiceProvider',
    ),
  ),
  'vyuldashev/nova-money-field' => 
  array (
    'providers' => 
    array (
      0 => 'Vyuldashev\\NovaMoneyField\\FieldServiceProvider',
    ),
  ),
  'yassi/nova-nested-form' => 
  array (
    'providers' => 
    array (
      0 => 'Yassi\\NestedForm\\FieldServiceProvider',
    ),
  ),
  'zareismail/nova-trust' => 
  array (
    'providers' => 
    array (
      0 => 'NovaTrust\\ToolServiceProvider',
    ),
  ),
  'zareismail/nova-wizard' => 
  array (
    'providers' => 
    array (
      0 => 'Zareismail\\NovaWizard\\ToolServiceProvider',
    ),
  ),
);