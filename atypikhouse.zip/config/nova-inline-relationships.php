<?php

return [
    'third-party' => [
        'KirschbaumDevelopment\NovaInlineRelationship\Integrations',
    ],
];
