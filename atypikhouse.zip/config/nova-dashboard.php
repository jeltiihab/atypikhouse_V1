<?php

declare(strict_types = 1);

use DigitalCreative\NovaDashboard\Models\Widget;

return [

    'widget_model' => Widget::class,
    'table_name' => 'widgets',

];
