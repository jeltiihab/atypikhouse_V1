<h3 class="flex items-center font-normal text-white mb-6 text-base no-underline">
    <span class="sidebar-label">
        <?php echo e(__('Dashboard Manager')); ?>

    </span>
</h3>

<ul class="list-reset mb-8">
        <?php $__currentLoopData = $dashboards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="leading-tight mb-4 ml-8 text-sm">
            <router-link
                class="text-white text-justify no-underline dim"
                :to="{
                    name: 'nova-dashboard',
                    params: {
                        dashboardKey: '<?php echo $resource->resourceUri(); ?>'
                    },
                    query: {
                        dashboardId: <?php echo e($resource->resourceId()); ?>

                    }
                }">
                <?php echo e($resource->resourceLabel()); ?>

            </router-link>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <li>
        <h4 class="ml-8 mb-4 text-xs text-white-50% uppercase tracking-wide"><?php echo e(__('Configuration')); ?></h4>
    </li>

        <li class="leading-wide mb-2 text-sm">
            <router-link :to="{
                    name: 'index',
                    params: {
                        resourceName: '<?php echo e(NovaBi\NovaDashboardManager\Nova\DashboardConfiguration::uriKey()); ?>',
                    }
                }" class="text-white ml-8 no-underline dim">
                - <?php echo e(__('Dashboard')); ?>

            </router-link>
        </li>
        <li class="leading-wide mb-2 text-sm">
            <router-link :to="{
                    name: 'index',
                    params: {
                        resourceName: '<?php echo e(\NovaBi\NovaDashboardManager\Nova\Datawidget::uriKey()); ?>',
                    }
                }" class="text-white ml-8 no-underline dim">
                - <?php echo e(__('Widgets')); ?>

            </router-link>
        </li>
        <li class="leading-wide mb-2 text-sm">
            <router-link :to="{
                    name: 'index',
                    params: {
                        resourceName: '<?php echo e(\NovaBi\NovaDashboardManager\Nova\Datafilter::uriKey()); ?>',
                    }
                }" class="text-white ml-8 no-underline dim">
                - <?php echo e(__('Filter')); ?>

            </router-link>
        </li>
</ul>
<?php /**PATH C:\laragon\www\atypikhouse\vendor\nova-bi\nova-dashboard-manager\src/../resources/views/navigation.blade.php ENDPATH**/ ?>