<?php if($request['sortable']): ?>
    ->sortable()
<?php endif; ?><?php /**PATH C:\laragon\www\atypikhouse\vendor\cloudstudio\resource-generator\src/../resources/views/fields/options/sortable.blade.php ENDPATH**/ ?>