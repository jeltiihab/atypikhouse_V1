<?php if(isset($request['min'])): ?>
	->min(<?php echo e($request['min']); ?>)
<?php endif; ?>
<?php if(isset($request['max'])): ?>
	->max(<?php echo e($request['max']); ?>)
<?php endif; ?>
<?php if(isset($request['step'])): ?>
	->step(<?php echo e($request['step']); ?>)
<?php endif; ?><?php /**PATH C:\laragon\www\atypikhouse\vendor\cloudstudio\resource-generator\src/../resources/views/fields/options/number.blade.php ENDPATH**/ ?>