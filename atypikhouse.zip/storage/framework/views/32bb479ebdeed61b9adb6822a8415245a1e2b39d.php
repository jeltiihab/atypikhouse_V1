<div class="mx-auto py-8 max-w-sm text-center text-90">
    <?php echo $__env->make('nova::auth.partials.logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH C:\laragon\www\atypikhouse\nova\src/../resources/views/auth/partials/header.blade.php ENDPATH**/ ?>