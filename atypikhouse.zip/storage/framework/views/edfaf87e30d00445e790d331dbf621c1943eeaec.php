<?php if(isset($request['loadingWhen'])): ?>
    ->loadingWhen([
    	<?php $__currentLoopData = $request['loadingWhen']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loadingWhen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    '<?php echo e($loadingWhen); ?>',
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	])
<?php endif; ?>
<?php if(isset($request['failedWhen'])): ?>
    ->failedWhen([
    	<?php $__currentLoopData = $request['failedWhen']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $failedWhen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    '<?php echo e($failedWhen); ?>',
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	])
<?php endif; ?><?php /**PATH C:\laragon\www\atypikhouse\vendor\cloudstudio\resource-generator\src/../resources/views/fields/options/status.blade.php ENDPATH**/ ?>