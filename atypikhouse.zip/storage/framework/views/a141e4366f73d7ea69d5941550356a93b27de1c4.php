<?php if(isset($request['language'])): ?>
	<?php if($request['language'] == 'json'): ?>
		->json()
	<?php else: ?>
		->language('<?php echo e($request['language']); ?>')
	<?php endif; ?>
<?php endif; ?> <?php /**PATH C:\laragon\www\atypikhouse\vendor\cloudstudio\resource-generator\src/../resources/views/fields/options/code.blade.php ENDPATH**/ ?>