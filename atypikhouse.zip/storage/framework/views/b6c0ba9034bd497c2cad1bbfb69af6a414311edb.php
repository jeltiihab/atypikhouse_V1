<?php if(isset($request['searchable'])): ?>
    ->searchable()
<?php endif; ?><?php /**PATH C:\laragon\www\atypikhouse\vendor\cloudstudio\resource-generator\src/../resources/views/fields/options/searchable.blade.php ENDPATH**/ ?>