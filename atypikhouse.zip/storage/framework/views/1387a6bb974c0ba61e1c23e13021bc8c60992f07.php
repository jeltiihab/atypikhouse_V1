<?php if($request['show'] !== 'all'): ?>
    -><?php echo e($request['show']); ?>()
<?php endif; ?><?php /**PATH C:\laragon\www\atypikhouse\vendor\cloudstudio\resource-generator\src/../resources/views/fields/options/show.blade.php ENDPATH**/ ?>