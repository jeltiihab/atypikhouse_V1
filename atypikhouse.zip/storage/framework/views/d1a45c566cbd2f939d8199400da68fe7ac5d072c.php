@phptag

namespace <?php echo e($namespace); ?><?php echo e($resource); ?>;

use Illuminate\Http\Request;
<?php $__currentLoopData = $unique; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
use Laravel\Nova\Fields\<?php echo e($type); ?>;
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


class <?php echo e($request['singular']); ?> extends Resource
{
    /**
     * The model the resource corresponds to.
     *
     * @var  string
     */
    public static $model = \<?php echo e($model); ?>\<?php echo e($request['singular']); ?>::class;

    /**
     * The single value that should be used to represent the resource when being displayed.
     *
     * @var  string
     */
    public static $title = '<?php echo e($request['title']); ?>';

    /**
     * The columns that should be searched.
     *
     * @var  array
     */
    public static $search = [
        <?php echo $search; ?>

    ];

    /**
     * Get the displayable label of the resource.
     *
     * @return  string
     */
    public static function label()
    {
        return __('<?php echo e(\Str::plural(\ucwords(\Str::snake($request['singular'], ' ')))); ?>');
    }

    /**
    * Get the displayable singular label of the resource.
    *
    * @return  string
    */
    public static function singularLabel()
    {
        return __('<?php echo e(\ucwords(\Str::snake($request['singular'], ' '))); ?>');
    }

    /**
     * Get the fields displayed by the resource.
     *
     * @param    \Illuminate\Http\Request  $request
     * @return  array
     */
    public function fields(Request $request)
    {
        return [
            <?php $__currentLoopData = $request['columns']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($request['show'] !== 'disabled'): ?>
                    <?php echo $__env->make('resource-generator::fields/magic', ['request' => $request], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>,
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ];
    }

    /**
     * Get the cards available for the request.
     *
     * @param    \Illuminate\Http\Request  $request
     * @return  array
     */
    public function cards(Request $request)
    {
        return [];
    }

    /**
     * Get the filters available for the resource.
     *
     * @param    \Illuminate\Http\Request  $request
     * @return  array
     */
    public function filters(Request $request)
    {
        return [];
    }

    /**
     * Get the lenses available for the resource.
     *
     * @param    \Illuminate\Http\Request  $request
     * @return  array
     */
    public function lenses(Request $request)
    {
        return [];
    }

    /**
     * Get the actions available for the resource.
     *
     * @param    \Illuminate\Http\Request  $request
     * @return  array
     */
    public function actions(Request $request)
    {
        return [];
    }
}
<?php /**PATH C:\laragon\www\atypikhouse\vendor\cloudstudio\resource-generator\src/../resources/views/templates/resource.blade.php ENDPATH**/ ?>