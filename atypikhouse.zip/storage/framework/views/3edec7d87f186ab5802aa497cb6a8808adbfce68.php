<?php if(isset($request['trueValue'])): ?>
    ->trueValue('<?php echo e($request['trueValue']); ?>')
<?php endif; ?> 
<?php if(isset($request['falseValue'])): ?>
    ->falseValue('<?php echo e($request['falseValue']); ?>')
<?php endif; ?><?php /**PATH C:\laragon\www\atypikhouse\vendor\cloudstudio\resource-generator\src/../resources/views/fields/options/boolean.blade.php ENDPATH**/ ?>