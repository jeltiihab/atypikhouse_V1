<?php if(isset($request['cities'])): ?>
	<?php if($request['cities']): ?>
	    ->countries([
	    	<?php $__currentLoopData = $request['cities']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		    '<?php echo e($country); ?>',
		    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		])
	<?php endif; ?>
	<?php if($request['onlyCities'] == 'true'): ?>
		->onlyCities()
	<?php endif; ?>
<?php endif; ?><?php /**PATH C:\laragon\www\atypikhouse\vendor\cloudstudio\resource-generator\src/../resources/views/fields/options/place.blade.php ENDPATH**/ ?>