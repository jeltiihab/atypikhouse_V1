<div style='text-align: center; margin-bottom: 10px; padding: 10px'>
    <h3 styles='padding-top: 15px; margin-bottom: 10px;'>Bonjour</h3>
    <p styles='padding-top: 15px; margin-bottom: 10px; color: gray'>
        Nos admin ont ajoutée des nouveaux propriétés <b>"<?php echo e($attribute->name); ?>"</b> dynamique a l'une de vos
        Biens.
        <br /> Merci de visiter ce lien pour pouvoir modifier/ajouter cette
        nouvelle information ?
    </p>
    <a href='#'>
        <button
            style='border: none;
          background-color: #008CBA;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;'
        >
            Mes biens
        </button>
    </a>
</div>
<?php /**PATH C:\laragon\www\atypikhouse\resources\views/mails/attributeAdded.blade.php ENDPATH**/ ?>