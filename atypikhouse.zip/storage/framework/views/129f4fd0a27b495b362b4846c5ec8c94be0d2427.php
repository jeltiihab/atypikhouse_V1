<?php if(isset($request['disk'])): ?>
	->disk('<?php echo e($request['disk']); ?>')
	<?php if(isset($request['prunable']) and $request['prunable'] == 'true'): ?>
		->prunable()
	<?php endif; ?>
<?php endif; ?> <?php /**PATH C:\laragon\www\atypikhouse\vendor\cloudstudio\resource-generator\src/../resources/views/fields/options/file.blade.php ENDPATH**/ ?>