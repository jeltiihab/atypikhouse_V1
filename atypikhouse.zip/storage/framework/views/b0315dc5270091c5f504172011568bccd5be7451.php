<?php if($request['required']): ?>
    ->rules('required')
<?php endif; ?><?php /**PATH C:\laragon\www\atypikhouse\vendor\cloudstudio\resource-generator\src/../resources/views/fields/options/required.blade.php ENDPATH**/ ?>