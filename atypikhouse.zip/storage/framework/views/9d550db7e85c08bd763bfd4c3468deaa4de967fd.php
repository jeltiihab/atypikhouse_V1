<p class="mt-8 text-center text-xs text-80">
    <a href="#" class="text-primary dim no-underline">Atypikhouse</a>
    <span class="px-1">&middot;</span>
    &copy; <?php echo e(date('Y')); ?> Atypikhouse SARL.
    <span class="px-1">&middot;</span>

</p>
<?php /**PATH C:\laragon\www\atypikhouse\resources\views/vendor/nova/partials/footer.blade.php ENDPATH**/ ?>