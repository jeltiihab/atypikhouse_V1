<?php if(isset($request['options'])): ?>
    ->options([
    	<?php $__currentLoopData = $request['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    '<?php echo e($key); ?>' => '<?php echo e($value); ?>',
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	])
<?php endif; ?><?php /**PATH C:\laragon\www\atypikhouse\vendor\cloudstudio\resource-generator\src/../resources/views/fields/options/select.blade.php ENDPATH**/ ?>