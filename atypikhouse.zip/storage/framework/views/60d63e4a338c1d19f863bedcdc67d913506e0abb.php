<?php if(isset($request['format'])): ?>
	->format('<?php echo e($request['format']); ?>')
<?php endif; ?> <?php /**PATH C:\laragon\www\atypikhouse\vendor\cloudstudio\resource-generator\src/../resources/views/fields/options/format.blade.php ENDPATH**/ ?>