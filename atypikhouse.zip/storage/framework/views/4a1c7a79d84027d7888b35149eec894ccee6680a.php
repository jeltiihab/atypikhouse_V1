<p> AtypikHouse</p>
<?php /**PATH C:\laragon\www\atypikhouse\resources\views/vendor/nova/partials/logo.blade.php ENDPATH**/ ?>